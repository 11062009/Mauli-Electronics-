# माऊली इलेक्ट्रॉनिक्स — Starter Website

## Before publishing
1. Open `index.html` in a text editor.
2. Find `const STORE_WHATSAPP = "REPLACE_WITH_YOUR_WHATSAPP_NUMBER";`
3. Replace the placeholder with the store's WhatsApp number including country code, digits only (India example format: `919876543210`). Never publish a personal number unless you intend customers to contact it.
4. Replace demo product names, descriptions, and prices in the `products` array with accurate store inventory. Demo products and prices are examples only.
5. Test cart and WhatsApp order before sharing the link.

## Test locally
Double-click `index.html` to open it in Chrome. Add a product to cart, enter customer details, and test only after setting the intended store WhatsApp number.

## Publish free with GitHub Pages
1. Sign in at https://github.com/ and create a new **public** repository, e.g. `mauli-electronics`.
2. Upload `index.html` to the repository's root folder.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/(root)`, then press **Save**.
6. Wait for publishing; open the URL shown in the Pages section (usually `https://YOUR-USERNAME.github.io/mauli-electronics/`).
7. Public repositories and their site content are visible on the internet. Do not include private/customer information in the code.

## Important limitations
- This is a static starter storefront. Cart runs in the visitor's browser.
- Orders are composed in WhatsApp; the customer must review and press Send.
- It does not process payments, reserve stock, keep an order database, or provide an admin dashboard.
- GitHub Pages hosts static files and does not run a private server/backend.
